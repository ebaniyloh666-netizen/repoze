# ROADMAP (implementation phases)

This repository is delivered in parts through chat. Part 1 includes:
- control plane + web UI + worker + runner skeleton
- DB schema, auth, project mgmt
- git workspace + templates
- verify loop (install/typecheck/lint/build)
- basic multi-agent loop (planner/ui/backend/qa) via LLM calls
- web search + site inspection tools

Part 2 will complete:
- structured tool-calling loop with strict schemas and memory
- real long-lived preview containers (not placeholder)
- export: zip + push to remote
- parallel branches/worktrees + judge selection
- secrets encryption + injection into sandbox
- usage accounting + quotas
- observability (OpenTelemetry) and audit UI
