import { runnerExec } from "./runnerClient.js";
import { WorkspaceManager } from "@forge0/workspace";

export function createVerifyClient(workspace: WorkspaceManager) {
  return {
    async run(args: { projectId: string; mode: "quick" | "full" }) {
      const dir = await workspace.ensureProject(args.projectId);

      // Install deps first (egress), then checks (no network).
      const install = await runnerExec({
        projectId: args.projectId,
        workspacePath: dir,
        cmd: ["bash", "-lc", "corepack enable && pnpm install --frozen-lockfile || pnpm install"],
        timeoutMs: 10 * 60 * 1000,
        network: "egress",
      });

      const checks: any[] = [];
      checks.push(
        await runnerExec({
          projectId: args.projectId,
          workspacePath: dir,
          cmd: ["bash", "-lc", "pnpm typecheck"],
          timeoutMs: 5 * 60 * 1000,
          network: "none",
        })
      );
      checks.push(
        await runnerExec({
          projectId: args.projectId,
          workspacePath: dir,
          cmd: ["bash", "-lc", "pnpm lint"],
          timeoutMs: 5 * 60 * 1000,
          network: "none",
        })
      );
      checks.push(
        await runnerExec({
          projectId: args.projectId,
          workspacePath: dir,
          cmd: ["bash", "-lc", "pnpm build"],
          timeoutMs: 10 * 60 * 1000,
          network: "none",
        })
      );

      const ok = checks.every((c) => (c.code ?? 1) === 0);
      return {
        ok,
        report: {
          install,
          checks,
          mode: args.mode,
        },
      };
    },
  };
}
