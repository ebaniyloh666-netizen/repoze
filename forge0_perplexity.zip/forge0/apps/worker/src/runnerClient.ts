import { request } from "undici";

const RUNNER_URL = process.env.RUNNER_URL ?? "http://localhost:5000";
const TOKEN = process.env.RUNNER_AUTH_TOKEN ?? "dev-runner-token";

export async function runnerExec(body: any) {
  const res = await request(`${RUNNER_URL}/exec`, {
    method: "POST",
    headers: { "content-type": "application/json", "x-runner-token": TOKEN },
    body: JSON.stringify(body),
  });
  if (res.statusCode >= 400) throw new Error(`runner exec failed: ${res.statusCode} ${await res.body.text()}`);
  return await res.body.json();
}
