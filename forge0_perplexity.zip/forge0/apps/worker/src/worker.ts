import { Worker } from "bullmq";
import IORedis from "ioredis";
import pino from "pino";
import path from "node:path";

import { db } from "@forge0/db";
import { WorkspaceManager } from "@forge0/workspace";
import { createToolRegistry } from "@forge0/tools";
import { Orchestrator, PerplexityLLM } from "@forge0/agent-core";
import { createSandboxClient } from "./sandboxClient.js";
import { createVerifyClient } from "./verifyClient.js";
import { postEvent } from "./internalClient.js";

const log = pino({ name: "forge0-worker" });
const prisma = db();

const REDIS_URL = process.env.REDIS_URL ?? "redis://localhost:6379";
const connection = new IORedis(REDIS_URL, { maxRetriesPerRequest: null });

const workspace = new WorkspaceManager({
  rootDir: process.env.WORKSPACE_ROOT ?? "workspace-data",
  templatesDir: path.resolve("packages/workspace/templates"),
});
const sandbox = createSandboxClient(workspace);
const verify = createVerifyClient(workspace);

const tools = createToolRegistry({ workspace, sandbox, verify });

const PPLX_KEY = process.env.PERPLEXITY_API_KEY ?? process.env.PPLX_API_KEY;
if (!PPLX_KEY) {
  throw new Error("Missing PERPLEXITY_API_KEY (or PPLX_API_KEY). The worker cannot run without an LLM key.");
}

const llm = new PerplexityLLM({
  apiKey: PPLX_KEY,
  baseUrl: process.env.PERPLEXITY_BASE_URL ?? process.env.PPLX_BASE_URL,
  model: process.env.PERPLEXITY_MODEL ?? process.env.PPLX_MODEL ?? "sonar-pro",
});

const orchestrator = new Orchestrator({
  llm,
  tools: tools as any,
  eventSink: {
    async emit(e) {
      await postEvent(e.runId, e);
    }
  },
  now: () => new Date(),
  isCancelled: async (rid) => {
    const row = await prisma.agentRun.findUnique({ where: { id: rid }, select: { status: true } });
    return row?.status === "cancelled";
  },
}, { parallelismDefault: 4, maxIterationsDefault: 15 });

new Worker("forge0-agent", async (job) => {
  if (job.name !== "agent.run") return;
  const { runId, projectId, prompt, maxIterations, parallelism } = job.data as any;

  await prisma.agentRun.update({ where: { id: runId }, data: { status: "running", startedAt: new Date() } });

  const res = await orchestrator.run({
    runId,
    projectId,
    userPrompt: prompt,
    maxIterations,
    parallelism,
  });

  await prisma.agentRun.update({
    where: { id: runId },
    data: { status: res.ok ? "succeeded" : "failed", finishedAt: new Date() },
  });

  log.info({ runId, ok: res.ok }, "agent run finished");
}, { connection });

log.info("worker started");
