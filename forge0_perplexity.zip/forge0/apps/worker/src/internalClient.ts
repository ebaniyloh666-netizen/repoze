import { request } from "undici";

const CONTROL = process.env.CONTROL_INTERNAL_URL ?? "http://localhost:4000";
const INTERNAL_TOKEN = process.env.CONTROL_INTERNAL_TOKEN ?? "dev-internal-token";

export async function postEvent(runId: string, e: any) {
  const res = await request(`${CONTROL}/internal/runs/${runId}/event`, {
    method: "POST",
    headers: { "content-type": "application/json", "x-internal-token": INTERNAL_TOKEN },
    body: JSON.stringify(e),
  });
  if (res.statusCode >= 400) throw new Error(`postEvent failed ${res.statusCode} ${await res.body.text()}`);
  return await res.body.json();
}
