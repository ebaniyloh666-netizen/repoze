import { runnerExec } from "./runnerClient.js";
import { WorkspaceManager } from "@forge0/workspace";

export function createSandboxClient(workspace: WorkspaceManager) {
  return {
    async exec(args: any) {
      const dir = await workspace.ensureProject(args.projectId);
      return await runnerExec({ ...args, workspacePath: dir });
    },
    async install(args: any) {
      const dir = await workspace.ensureProject(args.projectId);
      const pm = args.packageManager ?? "pnpm";
      const cmd = pm === "pnpm"
        ? ["bash","-lc","corepack enable && pnpm install --frozen-lockfile || pnpm install"]
        : pm === "npm"
        ? ["bash","-lc","npm ci || npm i"]
        : ["bash","-lc","yarn --frozen-lockfile || yarn"];
      return await runnerExec({
        projectId: args.projectId,
        workspacePath: dir,
        cmd,
        timeoutMs: 10*60*1000,
        network: "egress",
      });
    },
  };
}
