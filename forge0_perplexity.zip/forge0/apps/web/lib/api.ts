const CONTROL = process.env.NEXT_PUBLIC_CONTROL_URL ?? "http://localhost:4000";

export async function apiGet(path: string) {
  const res = await fetch(`${CONTROL}${path}`, { credentials: "include" });
  if (!res.ok) throw new Error(await res.text());
  return await res.json();
}

export async function apiPost(path: string, body?: any) {
  const res = await fetch(`${CONTROL}${path}`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    credentials: "include",
    body: body ? JSON.stringify(body) : undefined,
  });
  if (!res.ok) throw new Error(await res.text());
  return await res.json();
}
