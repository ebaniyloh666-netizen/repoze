import React from "react";

export function Button(props: React.ButtonHTMLAttributes<HTMLButtonElement> & { variant?: "primary" | "ghost" }) {
  const v = props.variant ?? "primary";
  const cls =
    v === "primary"
      ? "rounded-xl bg-white/10 px-3 py-2 text-sm font-medium hover:bg-white/15 transition"
      : "rounded-xl px-3 py-2 text-sm font-medium hover:bg-white/10 transition";
  return <button {...props} className={`${cls} ${props.className ?? ""}`} />;
}

export function Input(props: React.InputHTMLAttributes<HTMLInputElement>) {
  return (
    <input
      {...props}
      className={`w-full rounded-xl bg-white/5 px-3 py-2 text-sm outline-none ring-1 ring-white/10 focus:ring-white/25 ${props.className ?? ""}`}
    />
  );
}

export function Card(props: { title?: string; children: React.ReactNode; className?: string }) {
  return (
    <div className={`rounded-2xl bg-white/5 ring-1 ring-white/10 p-4 ${props.className ?? ""}`}>
      {props.title ? <div className="text-sm font-semibold mb-3">{props.title}</div> : null}
      {props.children}
    </div>
  );
}

export function Badge(props: { children: React.ReactNode }) {
  return <span className="inline-flex items-center rounded-full bg-white/10 px-2 py-0.5 text-xs">{props.children}</span>;
}
