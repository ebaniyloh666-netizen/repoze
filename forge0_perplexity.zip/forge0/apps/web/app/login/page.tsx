"use client";

import { useState } from "react";
import { apiPost } from "../../lib/api";
import { Button, Card, Input } from "../../components/ui";
import { useRouter } from "next/navigation";

export default function LoginPage() {
  const [email, setEmail] = useState("admin@forge0.local");
  const [password, setPassword] = useState("admin");
  const [err, setErr] = useState<string | null>(null);
  const r = useRouter();

  async function submit() {
    setErr(null);
    try {
      await apiPost("/api/login", { email, password });
      r.push("/app");
    } catch (e: any) {
      setErr(String(e.message ?? e));
    }
  }

  return (
    <main className="p-8 max-w-lg mx-auto">
      <Card title="Вход">
        <div className="space-y-3">
          <div>
            <div className="text-xs text-white/60 mb-1">Email</div>
            <Input value={email} onChange={(e) => setEmail(e.target.value)} />
          </div>
          <div>
            <div className="text-xs text-white/60 mb-1">Пароль</div>
            <Input type="password" value={password} onChange={(e) => setPassword(e.target.value)} />
          </div>
          {err ? <div className="text-sm text-red-300">{err}</div> : null}
          <Button onClick={submit}>Войти</Button>
        </div>
      </Card>
      <p className="mt-3 text-xs text-white/50">Dev-учётка по умолчанию: admin@forge0.local / admin</p>
    </main>
  );
}
