import Link from "next/link";

export default function Home() {
  return (
    <main className="p-8 max-w-5xl mx-auto">
      <div className="rounded-2xl bg-gradient-to-b from-white/10 to-white/5 ring-1 ring-white/10 p-6">
        <h1 className="text-2xl font-semibold">Forge0</h1>
        <p className="mt-2 text-white/70">
          Полноценный agentic builder: чат → код → проверка → предпросмотр → экспорт. Потому что людям мало страданий.
        </p>
        <div className="mt-5 flex gap-3">
          <Link href="/login" className="rounded-xl bg-white/15 px-4 py-2 text-sm font-medium hover:bg-white/20 transition">Войти</Link>
          <Link href="/app" className="rounded-xl px-4 py-2 text-sm font-medium hover:bg-white/10 transition">Открыть панель</Link>
        </div>
      </div>
    </main>
  );
}
