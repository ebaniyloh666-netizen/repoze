"use client";

import { useMemo, useState } from "react";
import useSWR from "swr";
import { apiGet, apiPost } from "../../../lib/api";
import { Button, Card, Input, Badge } from "../../../components/ui";
import dynamic from "next/dynamic";

const Monaco = dynamic(() => import("@monaco-editor/react"), { ssr: false });

const fetcher = (p: string) => apiGet(p);

type Tab = "chat" | "files" | "diff" | "logs" | "preview";

function flattenTree(nodes: any[], out: string[] = []) {
  for (const n of nodes) {
    if (n.type === "file") out.push(n.path);
    if (n.type === "dir") flattenTree(n.children ?? [], out);
  }
  return out;
}

export default function ProjectPage({ params }: any) {
  const projectId = params.id as string;
  const { data, mutate } = useSWR(`/api/projects/${projectId}`, fetcher);
  const [tab, setTab] = useState<Tab>("chat");
  const [prompt, setPrompt] = useState("");
  const [runId, setRunId] = useState<string | null>(null);

  const files = useMemo(() => flattenTree(data?.tree ?? []), [data?.tree]);
  const [selected, setSelected] = useState<string>("app/page.tsx");
  const fileKey = selected ? `/api/projects/${projectId}/file?path=${encodeURIComponent(selected)}` : null;
  const { data: fileData, mutate: mutateFile } = useSWR(fileKey, fetcher);

  const [events, setEvents] = useState<any[]>([]);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);

  async function startRun() {
    const r = await apiPost(`/api/projects/${projectId}/runs`, { prompt, maxIterations: 15, parallelism: 4 });
    setRunId(r.run.id);
    setEvents([]);
    setTab("logs");

    const ws = new WebSocket(`${process.env.NEXT_PUBLIC_CONTROL_URL?.replace("http","ws") ?? "ws://localhost:4000"}/ws/runs/${r.run.id}`);
    ws.onmessage = (m) => {
      try { setEvents((prev) => [...prev, JSON.parse(m.data)]); } catch {}
    };
    ws.onclose = () => {};
  }

  async function saveFile() {
    await apiPost(`/api/projects/${projectId}/file`, { path: selected, content: fileData?.content ?? "" });
    await mutate();
  }

  async function startPreview() {
    const p = await apiPost(`/api/projects/${projectId}/preview`);
    setPreviewUrl(`${process.env.NEXT_PUBLIC_CONTROL_URL ?? "http://localhost:4000"}${p.started.url}`);
    setTab("preview");
  }

  return (
    <main className="p-6 max-w-7xl mx-auto">
      <div className="flex items-center justify-between gap-3">
        <div>
          <div className="text-xs text-white/60">Project</div>
          <div className="text-xl font-semibold">{data?.project?.name ?? projectId}</div>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="ghost" onClick={() => setTab("chat")}>Chat</Button>
          <Button variant="ghost" onClick={() => setTab("files")}>Files</Button>
          <Button variant="ghost" onClick={() => setTab("logs")}>Logs</Button>
          <Button variant="ghost" onClick={() => setTab("preview")}>Preview</Button>
        </div>
      </div>

      <div className="mt-4 grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Card title="Управление" className="lg:col-span-1">
          <div className="space-y-3">
            <div>
              <div className="text-xs text-white/60 mb-1">Задача агенту</div>
              <textarea
                className="w-full h-28 rounded-xl bg-white/5 ring-1 ring-white/10 p-3 text-sm outline-none focus:ring-white/25"
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                placeholder="Опиши, какое веб-приложение нужно, какие страницы/данные/логика..."
              />
            </div>
            <Button onClick={startRun} disabled={!prompt.trim()}>Запустить агент</Button>
            <Button variant="ghost" onClick={startPreview}>Старт превью</Button>
            {runId ? <div className="text-xs text-white/60">Run: <span className="text-white/80">{runId}</span></div> : null}
          </div>
        </Card>

        <Card title="Рабочая область" className="lg:col-span-2">
          {tab === "chat" ? (
            <div className="text-sm text-white/70">
              Чат сейчас простой: запуск формирует run и стримит логи/события. В Part 2 добавлю полноценный диалог с tool-calling и контекстом.
            </div>
          ) : null}

          {tab === "files" ? (
            <div className="grid grid-cols-3 gap-3">
              <div className="col-span-1 space-y-2 max-h-[520px] overflow-auto pr-2">
                {files.map((f) => (
                  <button
                    key={f}
                    onClick={() => setSelected(f)}
                    className={`w-full text-left rounded-lg px-2 py-1 text-xs ${selected === f ? "bg-white/15" : "hover:bg-white/10"}`}
                  >
                    {f}
                  </button>
                ))}
              </div>
              <div className="col-span-2">
                <div className="flex items-center justify-between mb-2">
                  <div className="text-xs text-white/60">{selected}</div>
                  <Button onClick={saveFile} variant="ghost">Сохранить</Button>
                </div>
                <div className="h-[520px] rounded-xl overflow-hidden ring-1 ring-white/10">
                  <Monaco
                    language={selected.endsWith(".ts") || selected.endsWith(".tsx") ? "typescript" : "plaintext"}
                    value={fileData?.content ?? ""}
                    onChange={(v) => mutateFile({ ok: true, content: v ?? "" }, { revalidate: false })}
                    options={{ minimap: { enabled: false }, fontSize: 13 }}
                  />
                </div>
              </div>
            </div>
          ) : null}

          {tab === "logs" ? (
            <div className="max-h-[560px] overflow-auto space-y-2">
              {events.map((e, i) => (
                <div key={i} className="rounded-xl bg-black/20 ring-1 ring-white/10 p-3">
                  <div className="flex items-center justify-between">
                    <div className="text-xs text-white/60">{e.ts}</div>
                    <Badge>{e.kind}</Badge>
                  </div>
                  <div className="mt-1 text-sm">{e.message}</div>
                  {e.payload ? (
                    <pre className="mt-2 text-xs text-white/70 overflow-auto">{JSON.stringify(e.payload, null, 2)}</pre>
                  ) : null}
                </div>
              ))}
              {events.length === 0 ? <div className="text-sm text-white/60">Пока нет событий.</div> : null}
            </div>
          ) : null}

          {tab === "preview" ? (
            <div className="space-y-3">
              {previewUrl ? (
                <div className="rounded-xl overflow-hidden ring-1 ring-white/10">
                  <iframe src={previewUrl} className="w-full h-[560px]" />
                </div>
              ) : (
                <div className="text-sm text-white/60">Нажми “Старт превью”.</div>
              )}
              {previewUrl ? <div className="text-xs text-white/60">URL: <span className="text-white/80">{previewUrl}</span></div> : null}
            </div>
          ) : null}
        </Card>
      </div>
    </main>
  );
}
