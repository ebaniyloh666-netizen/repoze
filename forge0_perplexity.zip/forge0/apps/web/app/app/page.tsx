"use client";

import useSWR from "swr";
import Link from "next/link";
import { apiGet, apiPost } from "../lib/api";
import { Badge, Button, Card, Input } from "../components/ui";
import { useState } from "react";

const fetcher = (p: string) => apiGet(p);

export default function AppHome() {
  const { data, mutate, error } = useSWR("/api/projects", fetcher);
  const [name, setName] = useState("Новый проект");
  const [templateId, setTemplateId] = useState("nextjs-dashboard");

  async function create() {
    await apiPost("/api/projects", { name, templateId });
    await mutate();
  }

  return (
    <main className="p-8 max-w-6xl mx-auto">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-semibold">Проекты</h1>
        <Link href="/" className="text-sm text-white/60 hover:text-white">на главную</Link>
      </div>

      <div className="mt-5 grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card title="Создать проект">
          <div className="space-y-3">
            <Input value={name} onChange={(e) => setName(e.target.value)} />
            <div className="text-xs text-white/60">Template</div>
            <select
              className="w-full rounded-xl bg-white/5 ring-1 ring-white/10 px-3 py-2 text-sm"
              value={templateId}
              onChange={(e) => setTemplateId(e.target.value)}
            >
              <option value="nextjs-dashboard">nextjs-dashboard</option>
              <option value="nextjs-crud">nextjs-crud</option>
              <option value="nextjs-landing-auth">nextjs-landing-auth</option>
            </select>
            <Button onClick={create}>Создать</Button>
          </div>
        </Card>

        <Card title="Список">
          {error ? <div className="text-sm text-red-300">{String(error)}</div> : null}
          <div className="space-y-2">
            {(data?.projects ?? []).map((p: any) => (
              <Link key={p.id} href={`/app/projects/${p.id}`} className="block rounded-xl bg-white/5 ring-1 ring-white/10 p-3 hover:bg-white/10 transition">
                <div className="flex items-center justify-between">
                  <div className="font-medium">{p.name}</div>
                  <Badge>{p.runtime}</Badge>
                </div>
                <div className="mt-1 text-xs text-white/50">{new Date(p.updatedAt).toLocaleString()}</div>
              </Link>
            ))}
            {(data?.projects ?? []).length === 0 ? <div className="text-sm text-white/60">Пока пусто.</div> : null}
          </div>
        </Card>

        <Card title="Подсказка">
          <p className="text-sm text-white/70">
            Открывай проект, пиши задачу в чат, смотри дифф, проверку и превью. Потом экспортируй.
          </p>
        </Card>
      </div>
    </main>
  );
}
