import { randomBytes, timingSafeEqual } from "node:crypto";
import bcrypt from "bcryptjs";
import { db } from "@forge0/db";
import { z } from "zod";

const prisma = db();

export const zLogin = z.object({
  email: z.string().email(),
  password: z.string().min(3),
});

export async function login(email: string, password: string) {
  const user = await prisma.user.findUnique({ where: { email } });
  if (!user) return null;
  const ok = await bcrypt.compare(password, user.passwordHash);
  if (!ok) return null;

  const token = randomBytes(32).toString("hex");
  const expiresAt = new Date(Date.now() + 1000 * 60 * 60 * 24 * 14);
  await prisma.session.create({ data: { userId: user.id, token, expiresAt } });
  return { userId: user.id, token, expiresAt, email: user.email, name: user.name };
}

export async function requireSession(token?: string) {
  if (!token) return null;
  const sess = await prisma.session.findUnique({ where: { token }, include: { user: true } });
  if (!sess) return null;
  if (sess.expiresAt.getTime() < Date.now()) return null;
  return sess;
}

export function constantTimeEqual(a: string, b: string) {
  const ba = Buffer.from(a);
  const bb = Buffer.from(b);
  if (ba.length !== bb.length) return false;
  return timingSafeEqual(ba, bb);
}
