import type { AgentEventDTO } from "@forge0/shared";

export class EventHub {
  private subs = new Map<string, Set<(e: AgentEventDTO) => void>>();

  subscribe(runId: string, cb: (e: AgentEventDTO) => void) {
    if (!this.subs.has(runId)) this.subs.set(runId, new Set());
    this.subs.get(runId)!.add(cb);
    return () => this.subs.get(runId)!.delete(cb);
  }

  publish(e: AgentEventDTO) {
    const set = this.subs.get(e.runId);
    if (!set) return;
    for (const cb of set) cb(e);
  }
}
