import Fastify from "fastify";
import cors from "@fastify/cors";
import cookie from "@fastify/cookie";
import websocket from "@fastify/websocket";
import { z } from "zod";
import path from "node:path";

import { db } from "@forge0/db";
import { WorkspaceManager, listTemplates } from "@forge0/workspace";
import { createToolRegistry } from "@forge0/tools";
import { createVerifyClient } from "./verifyClient.js";
import { constantTimeEqual, login, requireSession, zLogin } from "./auth.js";
import { agentQueue } from "./queue.js";
import { EventHub } from "./events.js";
import type { AgentEventDTO } from "@forge0/shared";
import { zWorkspacePath } from "@forge0/shared";
import { runnerPreviewStart, runnerPreviewStop } from "./runnerClient.js";

const PORT = Number(process.env.CONTROL_PORT ?? 4000);
const WORKSPACE_ROOT = process.env.CONTROL_WORKSPACE_ROOT ?? "workspace-data";
const INTERNAL_TOKEN = process.env.CONTROL_INTERNAL_TOKEN ?? "dev-internal-token";

const prisma = db();
const app = Fastify({ logger: true });

await app.register(cors, { origin: true, credentials: true });
await app.register(cookie, { secret: process.env.FORGE0_COOKIE_SECRET ?? "dev-change-me" });
await app.register(websocket);

const workspace = new WorkspaceManager({
  rootDir: WORKSPACE_ROOT,
  templatesDir: path.resolve("packages/workspace/templates"),
});
const verify = createVerifyClient(workspace);

// Tools for agent workers are created there; but we keep registry here too for server-side operations.
const tools = createToolRegistry({
  workspace,
  sandbox: {
    exec: async () => ({ code: 1, stdout: "", stderr: "sandbox not available in control plane" }),
    install: async () => ({ code: 1, stdout: "", stderr: "sandbox not available in control plane" }),
  },
  verify,
});

// Control plane doesn't call tools directly yet (workers do), but keep registry here for future server-side ops.
void tools;

const hub = new EventHub();

app.get("/health", async () => ({ ok: true }));

// Auth
app.post("/api/login", async (req, reply) => {
  const body = zLogin.parse(req.body);
  const sess = await login(body.email, body.password);
  if (!sess) return reply.code(401).send({ ok: false });

  reply.setCookie("forge0_session", sess.token, {
    httpOnly: true,
    sameSite: "lax",
    path: "/",
    secure: false,
    maxAge: 60 * 60 * 24 * 14,
  });
  return { ok: true, user: { id: sess.userId, email: sess.email, name: sess.name } };
});

app.post("/api/logout", async (_req, reply) => {
  reply.clearCookie("forge0_session", { path: "/" });
  return { ok: true };
});

app.get("/api/me", async (req, reply) => {
  const token = (req.cookies as any).forge0_session;
  const sess = await requireSession(token);
  if (!sess) return reply.code(401).send({ ok: false });
  return { ok: true, user: { id: sess.user.id, email: sess.user.email, name: sess.user.name } };
});

async function requireUser(req: any, reply: any) {
  const token = req.cookies.forge0_session;
  const sess = await requireSession(token);
  if (!sess) {
    reply.code(401).send({ ok: false });
    return null;
  }
  return sess.user;
}

function requireInternal(req: any, reply: any) {
  const token = req.headers["x-internal-token"];
  const t = Array.isArray(token) ? token[0] : token;
  if (typeof t !== "string" || !constantTimeEqual(t, INTERNAL_TOKEN)) {
    reply.code(401).send({ ok: false });
    return false;
  }
  return true;
}

// Templates
app.get("/api/templates", async (_req, reply) => {
  const t = await listTemplates(path.resolve("packages/workspace"));
  reply.send({ ok: true, templates: t });
});

// Projects CRUD
app.get("/api/projects", async (req, reply) => {
  const user = await requireUser(req, reply);
  if (!user) return;
  const projects = await prisma.project.findMany({ where: { ownerId: user.id }, orderBy: { updatedAt: "desc" } });
  reply.send({ ok: true, projects });
});

app.post("/api/projects", async (req, reply) => {
  const user = await requireUser(req, reply);
  if (!user) return;

  const body = z.object({
    name: z.string().min(2).max(80),
    templateId: z.string().default("nextjs-dashboard"),
  }).parse(req.body);

  const project = await prisma.project.create({
    data: { ownerId: user.id, name: body.name, runtime: "nextjs" },
  });

  // init workspace
  const templatePath = path.resolve("packages/workspace/templates", body.templateId);
  await workspace.initFromTemplate(project.id, templatePath);
  const commitSha = await workspace.currentCommit(project.id);
  await prisma.projectVersion.create({ data: { projectId: project.id, commitSha, message: "init template" } });

  reply.send({ ok: true, project });
});

app.get("/api/projects/:id", async (req, reply) => {
  const user = await requireUser(req, reply);
  if (!user) return;

  const id = (req.params as any).id;
  const project = await prisma.project.findFirst({ where: { id, ownerId: user.id } });
  if (!project) return reply.code(404).send({ ok: false });

  const tree = await workspace.tree(id, 6);
  const versions = await prisma.projectVersion.findMany({ where: { projectId: id }, orderBy: { createdAt: "desc" }, take: 20 });
  reply.send({ ok: true, project, tree, versions });
});

app.get("/api/projects/:id/file", async (req, reply) => {
  const user = await requireUser(req, reply);
  if (!user) return;

  const id = (req.params as any).id;
  const q = z.object({ path: zWorkspacePath }).parse(req.query);
  const project = await prisma.project.findFirst({ where: { id, ownerId: user.id } });
  if (!project) return reply.code(404).send({ ok: false });

  const content = await workspace.readFile(id, q.path);
  reply.send({ ok: true, content });
});

app.post("/api/projects/:id/file", async (req, reply) => {
  const user = await requireUser(req, reply);
  if (!user) return;

  const id = (req.params as any).id;
  const body = z.object({ path: zWorkspacePath, content: z.string() }).parse(req.body);
  const project = await prisma.project.findFirst({ where: { id, ownerId: user.id } });
  if (!project) return reply.code(404).send({ ok: false });

  await workspace.writeFile(id, body.path, body.content);
  const c = await workspace.commit(id, `chore: edit ${body.path}`);
  if (c.changed) await prisma.projectVersion.create({ data: { projectId: id, commitSha: c.commit, message: c.message ?? "edit" } as any });
  reply.send({ ok: true });
});

// Agent run: enqueue job
app.post("/api/projects/:id/runs", async (req, reply) => {
  const user = await requireUser(req, reply);
  if (!user) return;

  const projectId = (req.params as any).id;
  const body = z.object({
    prompt: z.string().min(3),
    maxIterations: z.number().int().min(1).max(50).default(15),
    parallelism: z.number().int().min(1).max(8).default(4),
  }).parse(req.body);

  const project = await prisma.project.findFirst({ where: { id: projectId, ownerId: user.id } });
  if (!project) return reply.code(404).send({ ok: false });

  const run = await prisma.agentRun.create({
    data: { projectId, userPrompt: body.prompt, maxIters: body.maxIterations, parallelism: body.parallelism, status: "queued" },
  });

  await agentQueue.add("agent.run", { runId: run.id, projectId, prompt: body.prompt, maxIterations: body.maxIterations, parallelism: body.parallelism });

  reply.send({ ok: true, run });
});

// Events websocket: /ws/runs/:runId
app.get("/ws/runs/:runId", { websocket: true }, (conn, req) => {
  const runId = (req.params as any).runId;
  const unsub = hub.subscribe(runId, (e) => {
    try { conn.socket.send(JSON.stringify(e)); } catch {}
  });
  conn.socket.on("close", () => unsub());
});

// Persist + fanout events from workers
app.post("/internal/runs/:runId/event", async (req, reply) => {
  if (!requireInternal(req, reply)) return;
  const runId = (req.params as any).runId;
  const body = z.object({
    level: z.string(),
    kind: z.string(),
    role: z.string().optional(),
    message: z.string(),
    payload: z.any().optional(),
    ts: z.string().optional(),
  }).parse(req.body);

  await prisma.agentEvent.create({
    data: {
      runId,
      level: body.level,
      kind: body.kind,
      role: body.role,
      message: body.message,
      payload: body.payload,
      ts: body.ts ? new Date(body.ts) : new Date(),
    },
  });

  const e: AgentEventDTO = {
    runId,
    ts: body.ts ?? new Date().toISOString(),
    level: body.level as any,
    kind: body.kind as any,
    role: body.role as any,
    message: body.message,
    payload: body.payload,
  };
  hub.publish(e);
  reply.send({ ok: true });
});

// Preview start
app.post("/api/projects/:id/preview", async (req, reply) => {
  const user = await requireUser(req, reply);
  if (!user) return;
  const projectId = (req.params as any).id;
  const project = await prisma.project.findFirst({ where: { id: projectId, ownerId: user.id } });
  if (!project) return reply.code(404).send({ ok: false });

  const dir = await workspace.ensureProject(projectId);
  const started = await runnerPreviewStart({ projectId, workspacePath: dir, port: 3007 });
  const preview = await prisma.previewInstance.create({
    data: { projectId, status: "running", baseUrl: started.url },
  });
  reply.send({ ok: true, preview, started });
});

// Preview stop (stops the most recent running preview for the project)
app.post("/api/projects/:id/preview/stop", async (req, reply) => {
  const user = await requireUser(req, reply);
  if (!user) return;
  const projectId = (req.params as any).id;
  const project = await prisma.project.findFirst({ where: { id: projectId, ownerId: user.id } });
  if (!project) return reply.code(404).send({ ok: false });

  const preview = await prisma.previewInstance.findFirst({
    where: { projectId, status: "running" },
    orderBy: { createdAt: "desc" },
  });
  if (!preview?.baseUrl) return reply.code(404).send({ ok: false, error: "no running preview" });

  let previewId = "";
  try {
    const u = new URL(preview.baseUrl);
    const parts = u.pathname.split("/").filter(Boolean);
    // /preview/:id/...
    previewId = parts[0] === "preview" ? (parts[1] ?? "") : "";
  } catch {
    // ignore
  }
  if (!previewId) return reply.code(400).send({ ok: false, error: "invalid preview url" });

  await runnerPreviewStop({ previewId });
  await prisma.previewInstance.update({
    where: { id: preview.id },
    data: { status: "stopped", stoppedAt: new Date() },
  });

  reply.send({ ok: true });
});

app.listen({ port: PORT, host: "0.0.0.0" });
