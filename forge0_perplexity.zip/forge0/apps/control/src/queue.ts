import { Queue } from "bullmq";
import IORedis from "ioredis";

const REDIS_URL = process.env.REDIS_URL ?? "redis://localhost:6379";

export const connection = new IORedis(REDIS_URL, { maxRetriesPerRequest: null });

export const agentQueue = new Queue("forge0-agent", { connection });
export const verifyQueue = new Queue("forge0-verify", { connection });
export const previewQueue = new Queue("forge0-preview", { connection });
