import OpenAI from "openai";
import type { ChatMessage, ToolName } from "@forge0/shared";

export interface ModelToolCall {
  id: string;
  name: ToolName;
  /** Parsed args (best-effort). */
  arguments: any;
  /** Raw JSON string as produced by the model. */
  argumentsText: string;
}

export interface LLM {
  chat(opts: {
    messages: ChatMessage[];
    tools?: any[];
    toolChoice?: any;
    temperature?: number;
  }): Promise<{ text: string; toolCalls?: ModelToolCall[] }>;
}

/**
 * OpenAI-compatible chat client.
 *
 * NOTE: This is intentionally "OpenAI-compatible" rather than "OpenAI-only".
 * Perplexity's Sonar API is OpenAI Chat Completions compatible (base_url override).
 */
export class OpenAICompatibleLLM implements LLM {
  protected client: OpenAI;
  protected model: string;

  constructor(opts: { apiKey: string; model: string; baseUrl?: string }) {
    this.client = new OpenAI({ apiKey: opts.apiKey, baseURL: opts.baseUrl });
    this.model = opts.model;
  }

  async chat(opts: {
    messages: ChatMessage[];
    tools?: any[];
    toolChoice?: any;
    temperature?: number;
  }): Promise<{ text: string; toolCalls?: ModelToolCall[] }> {
    const res = await this.client.chat.completions.create({
      model: this.model,
      messages: opts.messages.map(toProviderMessage) as any,
      ...(opts.tools ? { tools: opts.tools as any } : {}),
      ...(opts.toolChoice ? { tool_choice: opts.toolChoice as any } : {}),
      temperature: opts.temperature ?? 0.2,
    });

    const msg: any = res.choices?.[0]?.message;
    const text = msg?.content ?? "";
    const toolCalls: ModelToolCall[] | undefined = msg?.tool_calls?.map((tc: any) => {
      const argsText = tc?.function?.arguments ?? "{}";
      return {
        id: tc.id,
        name: tc.function.name,
        argumentsText: argsText,
        arguments: safeJson(argsText),
      };
    });

    return { text, toolCalls };
  }
}

/**
 * Perplexity Sonar LLM (Chat Completions API).
 *
 * Base URL defaults to https://api.perplexity.ai.
 */
export class PerplexityLLM extends OpenAICompatibleLLM {
  constructor(opts: { apiKey: string; model: string; baseUrl?: string }) {
    super({ ...opts, baseUrl: opts.baseUrl ?? "https://api.perplexity.ai" });
  }
}

/**
 * Back-compat alias.
 *
 * The project initially used OpenAI directly; we keep the name to avoid noisy refactors.
 */
export class OpenAILLM extends OpenAICompatibleLLM {}

function toProviderMessage(m: ChatMessage) {
  const msg: any = { role: m.role, content: m.content };
  if (m.name) msg.name = m.name;

  // If this assistant message is a tool-call carrier, preserve tool_calls for round-tripping.
  if (m.role === "assistant" && m.toolCalls?.length) {
    msg.tool_calls = m.toolCalls.map((tc) => ({
      id: tc.id,
      type: "function",
      function: { name: tc.name, arguments: tc.argumentsText },
    }));
  }

  // Tool results must reference a preceding tool_call id.
  if (m.role === "tool") {
    if (m.toolCallId) msg.tool_call_id = m.toolCallId;
    // Some providers accept name on tool messages; harmless if ignored.
    if (m.name) msg.name = m.name;
  }

  return msg;
}

function safeJson(s: string) {
  try {
    return JSON.parse(s);
  } catch {
    return { _raw: s };
  }
}
