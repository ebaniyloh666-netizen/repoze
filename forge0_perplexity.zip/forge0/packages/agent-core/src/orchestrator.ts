import type { AgentEventDTO, AgentRole, AgentRunSpec, ChatMessage, ToolName } from "@forge0/shared";
import { nanoid } from "nanoid";
import pino from "pino";
import { makeSystemMessage } from "./roles.js";
import type { LLM } from "./llm.js";

export interface EventSink {
  emit(e: AgentEventDTO): Promise<void>;
}

export interface OrchestratorDeps {
  llm: LLM;
  tools: Record<string, (args: any) => Promise<any>>;
  eventSink: EventSink;
  now(): Date;
  /** Optional cancellation hook (e.g. DB status flag). */
  isCancelled?(runId: string): Promise<boolean>;
}

export interface OrchestratorConfig {
  parallelismDefault: number;
  maxIterationsDefault: number;
  /** Max tool-call roundtrips per single LLM call (role call). */
  maxToolStepsPerCall?: number;
  /** Disable tool calling entirely (debug/safety). */
  enableToolCalling?: boolean;
}

export class Orchestrator {
  private log = pino({ name: "forge0-orchestrator" });

  constructor(private deps: OrchestratorDeps, private cfg: OrchestratorConfig) {}

  async run(spec: AgentRunSpec & { runId?: string }) {
    const runId = spec.runId ?? nanoid(16);
    const maxIterations = spec.maxIterations ?? this.cfg.maxIterationsDefault;
    const parallelism = spec.parallelism ?? this.cfg.parallelismDefault;

    await this.deps.eventSink.emit(this.ev(runId, "info", "status", "running", { spec, maxIterations, parallelism }));

    // 1) Planning
    const plan = await this.callRole(runId, "planner", [
      { role: "user", content: spec.userPrompt },
      { role: "user", content: "Produce a spec + task list. Keep it structured. No code yet." },
    ]);
    await this.deps.eventSink.emit(this.ev(runId, "info", "plan", "Planner produced plan", { plan }));

    // 2) Template selection (simple heuristic; judge-based selection in Part 2)
    const template = spec.templateHint ?? inferTemplate(spec.userPrompt);
    await this.deps.eventSink.emit(this.ev(runId, "info", "log", `Selected template: ${template}`));

    // Initialize workspace from template
    // Control-plane should have already done this; but we keep the tool for idempotency.
    // We assume templates already copied; actual initFromTemplate happens in control-plane.

    // 3) Iterative multi-agent loop:
    // In each iteration: UI+Backend propose patches in parallel, Integrator merges, QA verifies, Fix loop.
    for (let iter = 1; iter <= maxIterations; iter++) {
      if (await this.deps.isCancelled?.(runId)) {
        await this.deps.eventSink.emit(this.ev(runId, "warn", "status", "cancelled"));
        return { runId, ok: false, reason: "cancelled" as const, iter: iter - 1, template, plan };
      }
      await this.deps.eventSink.emit(this.ev(runId, "info", "status", `iteration ${iter}/${maxIterations}`));

      const [ui, backend] = await Promise.allSettled([
        this.suggestChanges(runId, "ui", spec, plan, iter),
        this.suggestChanges(runId, "backend", spec, plan, iter),
      ]);

      const proposals = [
        ui.status === "fulfilled" ? ui.value : { role: "ui", patch: "", notes: String(ui.reason) },
        backend.status === "fulfilled" ? backend.value : { role: "backend", patch: "", notes: String(backend.reason) },
      ];

      // Integrator merges proposals (could be conflict resolution; here: apply sequentially).
      await this.deps.eventSink.emit(this.ev(runId, "info", "log", "Integrator applying patches", { proposals }));
      for (const p of proposals) {
        if (!p.patch?.trim()) continue;
        await this.tool(runId, "workspace.applyPatch", { projectId: spec.projectId, patch: p.patch });
      }
      const commit = await this.tool(runId, "workspace.commit", {
        projectId: spec.projectId,
        message: `iter ${iter}: apply agent proposals`,
      });
      await this.deps.eventSink.emit(this.ev(runId, "info", "commit", "Committed iteration", { commit }));

      // QA verify
      await this.deps.eventSink.emit(this.ev(runId, "info", "verify_start", "Running verification", { mode: "quick" }));
      const verify = await this.tool(runId, "verify.run", { projectId: spec.projectId, mode: "quick" });
      await this.deps.eventSink.emit(this.ev(runId, "info", "verify_result", "Verification result", verify));

      if (verify?.ok) {
        await this.deps.eventSink.emit(this.ev(runId, "info", "status", "succeeded", { iter }));
        return { runId, ok: true, iter, template, plan };
      }

      // Fix-loop: ask QA to propose a small patch based on report
      const fix = await this.callRole(runId, "qa", [
        { role: "user", content: "We have verification failures. Propose a minimal unified diff patch to fix them." },
        { role: "user", content: JSON.stringify(verify?.report ?? {}, null, 2) },
        { role: "user", content: "Return ONLY a unified diff patch. No commentary." },
      ], { temperature: 0.1 });

      if (looksLikeDiff(fix)) {
        await this.tool(runId, "workspace.applyPatch", { projectId: spec.projectId, patch: fix });
        const c2 = await this.tool(runId, "workspace.commit", { projectId: spec.projectId, message: `iter ${iter}: fix verification` });
        await this.deps.eventSink.emit(this.ev(runId, "info", "commit", "Committed fix", { c2 }));
      } else {
        await this.deps.eventSink.emit(this.ev(runId, "warn", "log", "QA did not return a valid patch; continuing", { fix }));
      }
    }

    await this.deps.eventSink.emit(this.ev(runId, "error", "status", "failed: max iterations exceeded"));
    return { runId, ok: false, reason: "max iterations" };
  }

  private async suggestChanges(runId: string, role: AgentRole, spec: AgentRunSpec, plan: string, iter: number) {
    const msg: ChatMessage[] = [
      { role: "user", content: spec.userPrompt },
      { role: "user", content: `Plan/spec:
${plan}` },
      { role: "user", content: `Iteration ${iter}. Propose a small set of changes. Output ONLY a unified diff patch.` },
      { role: "user", content: "Do not rewrite the whole project. Keep diffs minimal and correct." },
    ];
    const patch = await this.callRole(runId, role, msg, { temperature: 0.2 });
    return { role, patch, notes: `iter ${iter}` };
  }

  private async callRole(runId: string, role: AgentRole, messages: ChatMessage[], extra?: { temperature?: number }) {
    const enableTools = this.cfg.enableToolCalling ?? true;
    const maxSteps = Math.max(1, this.cfg.maxToolStepsPerCall ?? 6);

    const toolDefs = enableTools ? buildToolDefs() : undefined;
    const toolChoice = enableTools ? "auto" : undefined;

    const convo: ChatMessage[] = [makeSystemMessage(role), ...messages];

    for (let step = 1; step <= maxSteps; step++) {
      await this.deps.eventSink.emit(this.ev(runId, "info", "log", `LLM call role=${role} (step ${step}/${maxSteps})`));
      const res = await this.deps.llm.chat({
        messages: convo,
        ...(toolDefs ? { tools: toolDefs, toolChoice } : {}),
        temperature: extra?.temperature ?? 0.2,
      });

      if (res.toolCalls?.length) {
        // Preserve tool_calls on the assistant message so providers accept subsequent tool results.
        convo.push({
          role: "assistant",
          content: res.text ?? "",
          toolCalls: res.toolCalls.map((tc) => ({ id: tc.id, name: tc.name, argumentsText: tc.argumentsText })),
        });

        // Execute tools (sequential to keep ordering deterministic).
        for (const tc of res.toolCalls) {
          let out: any;
          try {
            out = await this.tool(runId, tc.name, tc.arguments);
          } catch (e: any) {
            out = { ok: false, error: String(e?.message ?? e), stack: e?.stack };
          }

          convo.push({
            role: "tool",
            name: tc.name,
            toolCallId: tc.id,
            content: JSON.stringify(out, null, 2),
          });
        }
        continue;
      }

      convo.push({ role: "assistant", content: res.text ?? "" });
      return res.text;
    }

    // If the model keeps calling tools forever, return whatever we have.
    const last = convo.slice().reverse().find((m) => m.role === "assistant")?.content ?? "";
    await this.deps.eventSink.emit(this.ev(runId, "warn", "log", `LLM tool loop exceeded max steps for role=${role}`));
    return last;
  }

  private async tool(runId: string, name: string, args: any) {
    await this.deps.eventSink.emit(this.ev(runId, "info", "tool_call", name, args));
    const fn = this.deps.tools[name];
    if (!fn) throw new Error(`tool not found: ${name}`);
    const res = await fn(args);
    await this.deps.eventSink.emit(this.ev(runId, "info", "tool_result", name, res));
    return res;
  }

  private ev(runId: string, level: any, kind: any, message: string, payload?: any): AgentEventDTO {
    return {
      runId,
      ts: this.deps.now().toISOString(),
      level,
      kind,
      message,
      payload,
    };
  }
}

function looksLikeDiff(s: string) {
  return /^diff --git /m.test(s) || /^--- /m.test(s);
}

function inferTemplate(prompt: string) {
  const p = prompt.toLowerCase();
  if (p.includes("dashboard") || p.includes("admin")) return "nextjs-dashboard";
  if (p.includes("crud") || p.includes("таблиц") || p.includes("список")) return "nextjs-crud";
  if (p.includes("landing") || p.includes("лендинг") || p.includes("логин")) return "nextjs-landing-auth";
  return "nextjs-dashboard";
}

function buildToolDefs() {
  // Keep these schemas intentionally simple and stable.
  // The runtime validators live in @forge0/shared zod schemas.
  const tools: any[] = [
    {
      type: "function",
      function: {
        name: "workspace.tree",
        description: "List files/folders in the project workspace.",
        parameters: {
          type: "object",
          properties: {
            projectId: { type: "string", description: "Project id" },
            ref: { type: "string", description: "Optional git ref/branch" },
            maxDepth: { type: "integer", minimum: 0, maximum: 8, default: 4 },
          },
          required: ["projectId"],
        },
      },
    },
    {
      type: "function",
      function: {
        name: "workspace.read",
        description: "Read a file from the project workspace.",
        parameters: {
          type: "object",
          properties: {
            projectId: { type: "string" },
            path: { type: "string", description: "Workspace-relative file path" },
            ref: { type: "string", description: "Optional git ref/branch" },
          },
          required: ["projectId", "path"],
        },
      },
    },
    {
      type: "function",
      function: {
        name: "workspace.write",
        description: "Write/overwrite a file in the project workspace.",
        parameters: {
          type: "object",
          properties: {
            projectId: { type: "string" },
            path: { type: "string" },
            content: { type: "string" },
          },
          required: ["projectId", "path", "content"],
        },
      },
    },
    {
      type: "function",
      function: {
        name: "workspace.applyPatch",
        description: "Apply a unified diff patch in the project workspace.",
        parameters: {
          type: "object",
          properties: {
            projectId: { type: "string" },
            patch: { type: "string", description: "Unified diff" },
          },
          required: ["projectId", "patch"],
        },
      },
    },
    {
      type: "function",
      function: {
        name: "workspace.commit",
        description: "Commit current workspace changes to git.",
        parameters: {
          type: "object",
          properties: {
            projectId: { type: "string" },
            message: { type: "string" },
            branch: { type: "string" },
          },
          required: ["projectId", "message"],
        },
      },
    },
    {
      type: "function",
      function: {
        name: "sandbox.install",
        description: "Install dependencies inside the sandbox for the project.",
        parameters: {
          type: "object",
          properties: {
            projectId: { type: "string" },
            packageManager: { type: "string", enum: ["pnpm", "npm", "yarn"], default: "pnpm" },
          },
          required: ["projectId"],
        },
      },
    },
    {
      type: "function",
      function: {
        name: "sandbox.exec",
        description: "Execute a command inside the sandbox for the project.",
        parameters: {
          type: "object",
          properties: {
            projectId: { type: "string" },
            cmd: { type: "array", items: { type: "string" }, minItems: 1 },
            cwd: { type: "string" },
            timeoutMs: { type: "integer", minimum: 1000, maximum: 900000, default: 300000 },
            env: { type: "object", additionalProperties: { type: "string" } },
            network: { type: "string", enum: ["none", "egress"], default: "egress" },
          },
          required: ["projectId", "cmd"],
        },
      },
    },
    {
      type: "function",
      function: {
        name: "verify.run",
        description: "Run project verification (lint/typecheck/build/tests).",
        parameters: {
          type: "object",
          properties: {
            projectId: { type: "string" },
            mode: { type: "string", enum: ["quick", "full"], default: "quick" },
          },
          required: ["projectId"],
        },
      },
    },
    {
      type: "function",
      function: {
        name: "web.search",
        description: "Search the web for information (returns URLs/snippets).",
        parameters: {
          type: "object",
          properties: {
            query: { type: "string" },
            maxResults: { type: "integer", minimum: 1, maximum: 10, default: 5 },
          },
          required: ["query"],
        },
      },
    },
    {
      type: "function",
      function: {
        name: "web.inspect",
        description: "Fetch a URL and (optionally) screenshot and extract text.",
        parameters: {
          type: "object",
          properties: {
            url: { type: "string" },
            screenshot: { type: "boolean", default: true },
            extractText: { type: "boolean", default: true },
            maxLinks: { type: "integer", minimum: 0, maximum: 50, default: 20 },
          },
          required: ["url"],
        },
      },
    },
  ];

  // Ensure the names are valid ToolName values at compile-time.
  return tools as Array<{ type: "function"; function: { name: ToolName } }>;
}
