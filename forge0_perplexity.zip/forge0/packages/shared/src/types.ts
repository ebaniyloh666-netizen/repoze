export type ID = string;

export type ProjectRuntime = "nextjs";

export type AgentRole =
  | "planner"
  | "ui"
  | "backend"
  | "qa"
  | "integrator"
  | "judge";

export type AgentStatus = "queued" | "running" | "succeeded" | "failed" | "cancelled";

export type ToolName =
  | "workspace.tree"
  | "workspace.read"
  | "workspace.write"
  | "workspace.applyPatch"
  | "workspace.commit"
  | "sandbox.exec"
  | "sandbox.install"
  | "verify.run"
  | "web.search"
  | "web.inspect";

export interface ToolCall<TArgs = unknown> {
  name: ToolName;
  args: TArgs;
}

export interface AssistantToolCall {
  /** Provider-generated id, required to pair tool results back to the call. */
  id: string;
  name: ToolName;
  /** Raw JSON string as produced by the model (kept for round-tripping). */
  argumentsText: string;
}

export interface ChatMessage {
  role: "system" | "user" | "assistant" | "tool";
  content: string;
  name?: string;
  /**
   * OpenAI-compatible tool calling support.
   * - role==='assistant': provide toolCalls (serialized tool_calls array)
   * - role==='tool': provide toolCallId (tool_call_id)
   */
  toolCalls?: AssistantToolCall[];
  toolCallId?: string;
}

export interface AgentRunSpec {
  projectId: ID;
  userPrompt: string;
  templateHint?: string;
  goals?: string[];
  constraints?: string[];
  maxIterations?: number;
  parallelism?: number;
}

export interface AgentEventDTO {
  runId: ID;
  ts: string;
  level: "debug" | "info" | "warn" | "error";
  kind:
    | "plan"
    | "tool_call"
    | "tool_result"
    | "patch"
    | "commit"
    | "verify_start"
    | "verify_result"
    | "status"
    | "log";
  role?: AgentRole;
  message: string;
  payload?: unknown;
}
