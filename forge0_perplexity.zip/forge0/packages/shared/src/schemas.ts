import { z } from "zod";

export const zId = z.string().min(10);

export const zAgentRunSpec = z.object({
  projectId: zId,
  userPrompt: z.string().min(3),
  templateHint: z.string().optional(),
  goals: z.array(z.string()).optional(),
  constraints: z.array(z.string()).optional(),
  maxIterations: z.number().int().min(1).max(50).optional(),
  parallelism: z.number().int().min(1).max(8).optional(),
});

export const zWorkspacePath = z.string().regex(/^[a-zA-Z0-9_./-]+$/).refine(p => !p.includes(".."), "no parent traversal");

export const zTool_workspace_tree = z.object({
  projectId: zId,
  ref: z.string().optional(),
  maxDepth: z.number().int().min(0).max(8).default(4),
});

export const zTool_workspace_read = z.object({
  projectId: zId,
  path: zWorkspacePath,
  ref: z.string().optional(),
});

export const zTool_workspace_write = z.object({
  projectId: zId,
  path: zWorkspacePath,
  content: z.string(),
});

export const zTool_workspace_applyPatch = z.object({
  projectId: zId,
  patch: z.string().min(1),
});

export const zTool_workspace_commit = z.object({
  projectId: zId,
  message: z.string().min(1).max(200),
  branch: z.string().optional(),
});

export const zTool_sandbox_exec = z.object({
  projectId: zId,
  cmd: z.array(z.string()).min(1),
  cwd: zWorkspacePath.optional(),
  timeoutMs: z.number().int().min(1000).max(15 * 60 * 1000).default(5 * 60 * 1000),
  env: z.record(z.string()).optional(),
  network: z.enum(["none", "egress"]).default("egress"),
});

export const zTool_sandbox_install = z.object({
  projectId: zId,
  packageManager: z.enum(["pnpm", "npm", "yarn"]).default("pnpm"),
});

export const zTool_verify_run = z.object({
  projectId: zId,
  mode: z.enum(["quick", "full"]).default("quick"),
});

export const zTool_web_search = z.object({
  query: z.string().min(2).max(300),
  maxResults: z.number().int().min(1).max(10).default(5),
});

export const zTool_web_inspect = z.object({
  url: z.string().url(),
  screenshot: z.boolean().default(true),
  extractText: z.boolean().default(true),
  maxLinks: z.number().int().min(0).max(50).default(20),
});
