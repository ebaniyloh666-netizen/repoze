import { db } from "../src/index.js";
import bcrypt from "bcryptjs";

async function main() {
  const prisma = db();
  const email = "admin@forge0.local";
  const password = "admin";
  const passwordHash = await bcrypt.hash(password, 10);

  await prisma.user.upsert({
    where: { email },
    update: {},
    create: { email, passwordHash, name: "Admin" },
  });

  console.log("Seeded:", { email, password });
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
