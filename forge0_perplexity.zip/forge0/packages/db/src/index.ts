import { PrismaClient } from "@prisma/client";

let _client: PrismaClient | null = null;

export function db(): PrismaClient {
  if (_client) return _client;
  _client = new PrismaClient();
  return _client;
}

export * from "@prisma/client";
