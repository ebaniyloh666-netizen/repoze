import Docker from "dockerode";
import fs from "node:fs/promises";
import path from "node:path";
import { nanoid } from "nanoid";
import { PassThrough } from "node:stream";

export type NetworkMode = "none" | "egress";

export interface RunnerConfig {
  dataDir: string;
  image: string;
}

export interface ExecResult {
  code: number;
  stdout: string;
  stderr: string;
}

export interface PreviewStartResult {
  containerId: string;
  hostPort: number;
  internalPort: number;
}

export class DockerRunner {
  private docker = new Docker();

  constructor(private cfg: RunnerConfig) {}

  async ensureImage() {
    try {
      await this.docker.getImage(this.cfg.image).inspect();
    } catch {
      await new Promise<void>((resolve, reject) => {
        this.docker.pull(this.cfg.image, (err, stream) => {
          if (err) return reject(err);
          this.docker.modem.followProgress(stream, (e) => (e ? reject(e) : resolve()));
        });
      });
    }
  }

  async execInWorkspace(opts: {
    projectId: string;
    workspacePath: string;
    cmd: string[];
    cwd?: string;
    env?: Record<string, string>;
    timeoutMs: number;
    network: NetworkMode;
  }): Promise<ExecResult> {
    await this.ensureImage();
    await fs.mkdir(this.cfg.dataDir, { recursive: true });

    const containerName = `forge0-exec-${opts.projectId}-${nanoid(6)}`;

    const binds = [
      `${path.resolve(opts.workspacePath)}:/work:rw`,
    ];

    const env = [
      "CI=1",
      ...(opts.env ? Object.entries(opts.env).map(([k, v]) => `${k}=${v}`) : []),
    ];

    const container = await this.docker.createContainer({
      name: containerName,
      Image: this.cfg.image,
      WorkingDir: opts.cwd ? path.posix.join("/work", opts.cwd) : "/work",
      Cmd: opts.cmd,
      Env: env,
      HostConfig: {
        AutoRemove: true,
        Binds: binds,
        NetworkMode: opts.network === "none" ? "none" : "bridge",
        Memory: 1024 * 1024 * 1024, // 1GiB default; make configurable in prod
        NanoCpus: 2_000_000_000, // 2 CPUs
        PidsLimit: 512,
        ReadonlyRootfs: false,
        SecurityOpt: [
          "no-new-privileges:true",
        ],
      },
      Tty: false,
      OpenStdin: false,
    });

    const logs = await container.attach({ stream: true, stdout: true, stderr: true });

    let stdout = "";
    let stderr = "";

    // Docker multiplexes stdout/stderr when Tty=false. Demux so callers can reason about failures.
    const outStream = new PassThrough();
    const errStream = new PassThrough();
    outStream.on("data", (chunk: Buffer) => { stdout += chunk.toString("utf-8"); });
    errStream.on("data", (chunk: Buffer) => { stderr += chunk.toString("utf-8"); });
    // @ts-ignore dockerode modem has demuxStream
    this.docker.modem.demuxStream(logs, outStream, errStream);

    const start = Date.now();
    await container.start();

    const timer = setInterval(async () => {
      if (Date.now() - start > opts.timeoutMs) {
        clearInterval(timer);
        try { await container.kill(); } catch {}
      }
    }, 500);

    const res = await container.wait();
    clearInterval(timer);

    return { code: res.StatusCode ?? 1, stdout, stderr };
  }

  async startPreview(opts: {
    projectId: string;
    workspacePath: string;
    internalPort: number;
    cmd: string[];
    env?: Record<string, string>;
  }): Promise<PreviewStartResult> {
    await this.ensureImage();
    await fs.mkdir(this.cfg.dataDir, { recursive: true });

    const containerName = `forge0-preview-${opts.projectId}-${nanoid(6)}`;
    const binds = [`${path.resolve(opts.workspacePath)}:/work:rw`];

    const env = [
      "CI=1",
      ...(opts.env ? Object.entries(opts.env).map(([k, v]) => `${k}=${v}`) : []),
    ];

    const portKey = `${opts.internalPort}/tcp`;
    const container = await this.docker.createContainer({
      name: containerName,
      Image: this.cfg.image,
      WorkingDir: "/work",
      Cmd: opts.cmd,
      Env: env,
      ExposedPorts: { [portKey]: {} },
      HostConfig: {
        AutoRemove: false,
        Binds: binds,
        NetworkMode: "bridge",
        PortBindings: { [portKey]: [{ HostPort: "0" }] },
        Memory: 1536 * 1024 * 1024,
        NanoCpus: 2_000_000_000,
        PidsLimit: 1024,
        ReadonlyRootfs: false,
        SecurityOpt: ["no-new-privileges:true"],
      },
      Tty: false,
      OpenStdin: false,
    });

    await container.start();
    const inspect = await container.inspect();
    const bindings = inspect?.NetworkSettings?.Ports?.[portKey] as Array<{ HostPort: string }> | undefined;
    const hostPort = Number(bindings?.[0]?.HostPort ?? 0);
    if (!hostPort) {
      try { await container.stop({ t: 0 }); } catch {}
      try { await container.remove({ force: true }); } catch {}
      throw new Error(`failed to allocate host port for preview (internal ${opts.internalPort})`);
    }

    return { containerId: inspect.Id, hostPort, internalPort: opts.internalPort };
  }

  async stopContainer(containerId: string): Promise<{ ok: boolean }> {
    const c = this.docker.getContainer(containerId);
    try {
      // stop might fail if already exited
      await c.stop({ t: 5 });
    } catch {}
    try {
      await c.remove({ force: true });
    } catch {}
    return { ok: true };
  }
}
