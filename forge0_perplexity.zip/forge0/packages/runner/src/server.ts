import Fastify from "fastify";
import cors from "@fastify/cors";
import { DockerRunner } from "./dockerRunner.js";
import { PreviewGateway } from "./previewGateway.js";
import { z } from "zod";
import fs from "node:fs/promises";

const PORT = Number(process.env.RUNNER_PORT ?? 5000);
const DATA_DIR = process.env.RUNNER_DATA_DIR ?? "runner-data";
const IMAGE = process.env.RUNNER_DOCKER_IMAGE ?? "node:20-bookworm";
const AUTH = process.env.RUNNER_AUTH_TOKEN ?? "dev-runner-token";

const app = Fastify({ logger: true });
await app.register(cors, { origin: true, credentials: true });

const runner = new DockerRunner({ dataDir: DATA_DIR, image: IMAGE });
const gateway = new PreviewGateway();

const PREVIEW_TTL_MS = Number(process.env.RUNNER_PREVIEW_TTL_MS ?? 2 * 60 * 60 * 1000);
const previews = new Map<string, { containerId: string; createdAt: number }>();

function requireAuth(req: any) {
  const token = req.headers["x-runner-token"];
  if (token !== AUTH) throw Object.assign(new Error("unauthorized"), { statusCode: 401 });
}

function absoluteBaseUrl(req: any) {
  // Prefer forwarded headers when behind a proxy.
  const proto = (req.headers["x-forwarded-proto"] ?? "http") as string;
  const host = (req.headers["x-forwarded-host"] ?? req.headers.host ?? `localhost:${PORT}`) as string;
  return `${proto}://${host}`;
}

app.get("/health", async () => ({ ok: true }));

app.post("/exec", async (req, reply) => {
  requireAuth(req);
  const body = z
    .object({
      projectId: z.string(),
      workspacePath: z.string(),
      cmd: z.array(z.string()).min(1),
      cwd: z.string().optional(),
      timeoutMs: z.number().int().optional(),
      env: z.record(z.string()).optional(),
      network: z.enum(["none", "egress"]).optional(),
    })
    .parse(req.body);

  const res = await runner.execInWorkspace({
    projectId: body.projectId,
    workspacePath: body.workspacePath,
    cmd: body.cmd,
    cwd: body.cwd,
    env: body.env,
    timeoutMs: body.timeoutMs ?? 5 * 60 * 1000,
    network: body.network ?? "egress",
  });
  reply.send(res);
});

/**
 * Preview is "best effort" in dev.
 *
 * For now, this API only registers a target and exposes it via the gateway.
 * A real implementation would manage long-lived containers, timeouts, quotas, and logs.
 */
app.post("/preview/start", async (req, reply) => {
  requireAuth(req);
  const body = z
    .object({
      projectId: z.string(),
      workspacePath: z.string(),
      port: z.number().int().default(3007),
      cmd: z.array(z.string()).default(["bash", "-lc", "corepack enable && pnpm dev -p 3007"]),
    })
    .parse(req.body);

  // Start a long-lived container and register it behind the gateway.
  const started = await runner.startPreview({
    projectId: body.projectId,
    workspacePath: body.workspacePath,
    internalPort: body.port,
    cmd: body.cmd,
  });

  const t = gateway.register(body.projectId, `http://localhost:${started.hostPort}`);
  previews.set(t.id, { containerId: started.containerId, createdAt: Date.now() });
  const base = absoluteBaseUrl(req);
  reply.send({ previewId: t.id, url: `${base}/preview/${t.id}/`, containerId: started.containerId, hostPort: started.hostPort });
});

app.post("/preview/stop", async (req, reply) => {
  requireAuth(req);
  const body = z
    .object({ previewId: z.string() })
    .parse(req.body);

  const meta = previews.get(body.previewId);
  gateway.unregister(body.previewId);
  previews.delete(body.previewId);

  if (meta?.containerId) {
    await runner.stopContainer(meta.containerId);
  }

  reply.send({ ok: true });
});

app.get("/preview/list", async (req) => {
  requireAuth(req);
  return Array.from(previews.entries()).map(([previewId, v]) => ({ previewId, ...v }));
});

// Best-effort preview cleanup.
setInterval(async () => {
  const now = Date.now();
  for (const [previewId, meta] of previews) {
    if (now - meta.createdAt < PREVIEW_TTL_MS) continue;
    gateway.unregister(previewId);
    previews.delete(previewId);
    try { await runner.stopContainer(meta.containerId); } catch {}
  }
}, Math.max(30_000, Math.min(300_000, Math.floor(PREVIEW_TTL_MS / 4))));

// Proxy endpoint: Fastify route that hijacks the raw Node response.
app.all("/preview/*", async (req, reply) => {
  reply.hijack();
  return gateway.handler()(req.raw, reply.raw);
});

// WebSocket proxy for previews only.
gateway.attachWebSocket(app.server);

await fs.mkdir(DATA_DIR, { recursive: true });
await app.listen({ port: PORT, host: "0.0.0.0" });
