import http from "node:http";
import httpProxy from "http-proxy";
import { nanoid } from "nanoid";

export interface PreviewTarget {
  id: string;
  projectId: string;
  targetUrl: string;
  createdAt: number;
}

export class PreviewGateway {
  private proxy = httpProxy.createProxyServer({ ws: true, changeOrigin: true });
  private targets = new Map<string, PreviewTarget>();

  register(projectId: string, targetUrl: string): PreviewTarget {
    const id = nanoid(10);
    const t: PreviewTarget = { id, projectId, targetUrl, createdAt: Date.now() };
    this.targets.set(id, t);
    return t;
  }

  unregister(id: string) {
    this.targets.delete(id);
  }

  handler(): http.RequestListener {
    return (req, res) => {
      const url = new URL(req.url ?? "/", "http://localhost");
      const id = url.pathname.split("/").filter(Boolean)[1]; // /preview/:id/...
      const t = this.targets.get(id);
      if (!t) {
        res.statusCode = 404;
        res.end("preview not found");
        return;
      }
      // strip /preview/:id
      req.url = url.pathname.replace(`/preview/${id}`, "") + url.search;
      this.proxy.web(req, res, { target: t.targetUrl });
    };
  }

  attachWebSocket(server: http.Server) {
    server.on("upgrade", (req, socket, head) => {
      const url = new URL(req.url ?? "/", "http://localhost");
      if (!url.pathname.startsWith("/preview/")) return;
      const id = url.pathname.split("/").filter(Boolean)[1];
      const t = this.targets.get(id);
      if (!t) return socket.destroy();
      req.url = url.pathname.replace(`/preview/${id}`, "") + url.search;
      this.proxy.ws(req, socket, head, { target: t.targetUrl });
    });
  }
}
