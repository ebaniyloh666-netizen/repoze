# Runner security

This runner executes untrusted code. You must harden:
- Run on isolated host/VM.
- Prefer rootless Docker or userns-remap.
- Limit CPU/memory/pids, set ulimits.
- Separate networks: allow egress only when installing deps; run app with `--network=none`.
- Deny mounting host paths except the workspace dir.

The default dev runner is not "production secure". Humans love shipping insecure sandboxes. Don't.
