import path from "node:path";
import fs from "node:fs/promises";
import { simpleGit } from "simple-git";
import { nanoid } from "nanoid";

export interface WorkspaceOptions {
  rootDir: string; // where repos live
  templatesDir: string; // packages/workspace/templates
}

export class WorkspaceManager {
  constructor(private opts: WorkspaceOptions) {}

  projectDir(projectId: string) {
    return path.join(this.opts.rootDir, projectId);
  }

  async ensureProject(projectId: string) {
    const dir = this.projectDir(projectId);
    await fs.mkdir(dir, { recursive: true });
    const git = simpleGit({ baseDir: dir });
    const isRepo = await git.checkIsRepo();
    if (!isRepo) {
      await git.init();
      await ensureGitIdentity(git);
      await fs.writeFile(path.join(dir, ".gitignore"), "node_modules\n.next\ndist\n.env\n", "utf-8");
      await git.add(".");
      await git.commit("chore: init workspace");
    }
    // Repo could exist without identity configured.
    await ensureGitIdentity(git);
    return dir;
  }

  async initFromTemplate(projectId: string, templatePath: string) {
    const dir = await this.ensureProject(projectId);
    // wipe working tree except .git
    const entries = await fs.readdir(dir);
    for (const e of entries) {
      if (e === ".git") continue;
      await fs.rm(path.join(dir, e), { recursive: true, force: true });
    }
    // copy template files
    await copyDir(templatePath, dir);
    const git = simpleGit({ baseDir: dir });
    await ensureGitIdentity(git);
    await git.add(".");
    await git.commit(`chore: apply template (${path.basename(templatePath)})`);
    return dir;
  }

  async tree(projectId: string, maxDepth = 4) {
    const dir = await this.ensureProject(projectId);
    return await readTree(dir, maxDepth);
  }

  async readFile(projectId: string, rel: string) {
    const dir = await this.ensureProject(projectId);
    const full = safeJoin(dir, rel);
    return await fs.readFile(full, "utf-8");
  }

  async writeFile(projectId: string, rel: string, content: string) {
    const dir = await this.ensureProject(projectId);
    const full = safeJoin(dir, rel);
    await fs.mkdir(path.dirname(full), { recursive: true });
    await fs.writeFile(full, content, "utf-8");
  }

  async applyPatch(projectId: string, patch: string) {
    const dir = await this.ensureProject(projectId);
    const git = simpleGit({ baseDir: dir });
    // Use git apply to keep behavior consistent with unified diffs.
    const tmp = path.join(dir, `.patch-${nanoid()}.diff`);
    await fs.writeFile(tmp, patch, "utf-8");
    try {
      await git.raw(["apply", "--whitespace=nowarn", tmp]);
    } finally {
      await fs.rm(tmp, { force: true });
    }
  }

  async commit(projectId: string, message: string, branch?: string) {
    const dir = await this.ensureProject(projectId);
    const git = simpleGit({ baseDir: dir });
    await ensureGitIdentity(git);
    if (branch) {
      const branches = await git.branchLocal();
      if (branches.all.includes(branch)) {
        await git.checkout(branch);
      } else {
        await git.checkoutLocalBranch(branch);
      }
    }
    await git.add(".");
    const status = await git.status();
    if (status.files.length === 0) {
      const head = await git.revparse(["HEAD"]);
      return { commit: head.trim(), changed: false };
    }
    const c = await git.commit(message);
    return { commit: c.commit, changed: true };
  }

  async currentCommit(projectId: string) {
    const dir = await this.ensureProject(projectId);
    const git = simpleGit({ baseDir: dir });
    const head = await git.revparse(["HEAD"]);
    return head.trim();
  }
}

function safeJoin(rootDir: string, rel: string) {
  // Prevent path traversal and accidental absolute paths.
  const full = path.resolve(rootDir, rel);
  const root = path.resolve(rootDir) + path.sep;
  if (!full.startsWith(root)) {
    throw new Error(`unsafe path: ${rel}`);
  }
  return full;
}

async function ensureGitIdentity(git: ReturnType<typeof simpleGit>) {
  // Git commits fail without identity, which is common in fresh containers.
  // Using local repo config avoids relying on global config.
  const name = process.env.GIT_AUTHOR_NAME ?? "forge0";
  const email = process.env.GIT_AUTHOR_EMAIL ?? "forge0@local";
  await git.addConfig("user.name", name).catch(() => {});
  await git.addConfig("user.email", email).catch(() => {});
}

async function copyDir(src: string, dst: string) {
  await fs.mkdir(dst, { recursive: true });
  const items = await fs.readdir(src, { withFileTypes: true });
  for (const it of items) {
    if (it.name === "node_modules" || it.name === ".next" || it.name === "dist") continue;
    const s = path.join(src, it.name);
    const d = path.join(dst, it.name);
    if (it.isDirectory()) await copyDir(s, d);
    else await fs.copyFile(s, d);
  }
}

async function readTree(root: string, maxDepth: number, prefix = "", depth = 0): Promise<any[]> {
  if (depth > maxDepth) return [];
  const dir = path.join(root, prefix);
  const items = await fs.readdir(dir, { withFileTypes: true });
  const res: any[] = [];
  for (const it of items) {
    if (it.name === ".git") continue;
    const rel = path.join(prefix, it.name);
    if (it.isDirectory()) {
      res.push({ type: "dir", path: rel, children: await readTree(root, maxDepth, rel, depth + 1) });
    } else {
      res.push({ type: "file", path: rel });
    }
  }
  return res;
}
