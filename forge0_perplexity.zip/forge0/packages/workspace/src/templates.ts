import path from "node:path";
import fs from "node:fs/promises";

export type TemplateId =
  | "nextjs-dashboard"
  | "nextjs-crud"
  | "nextjs-landing-auth";

export interface TemplateDescriptor {
  id: TemplateId;
  title: string;
  description: string;
  path: string;
}

export async function listTemplates(rootDir: string): Promise<TemplateDescriptor[]> {
  const dir = path.join(rootDir, "templates");
  await fs.mkdir(dir, { recursive: true });

  // Templates live in packages/workspace/templates/*
  const items = await fs.readdir(dir, { withFileTypes: true });
  const res: TemplateDescriptor[] = [];
  for (const it of items) {
    if (!it.isDirectory()) continue;
    const id = it.name as TemplateId;
    const tpath = path.join(dir, it.name);
    const metaPath = path.join(tpath, "template.json");
    try {
      const meta = JSON.parse(await fs.readFile(metaPath, "utf-8"));
      res.push({
        id,
        title: meta.title ?? id,
        description: meta.description ?? "",
        path: tpath,
      });
    } catch {
      // ignore broken template
    }
  }
  return res;
}
