export default function Page() {
  return (
    <main className="p-10">
      <h1 className="text-2xl font-semibold">Hello from Forge0 template</h1>
      <p className="mt-2 text-neutral-600">Edit this app via the Forge0 agent.</p>
    </main>
  );
}
