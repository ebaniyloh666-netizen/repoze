import { chromium } from "playwright";

export interface SiteInspection {
  url: string;
  finalUrl: string;
  title: string;
  html: string;
  text?: string;
  links: { href: string; text: string }[];
  screenshotBase64?: string;
}

export async function inspectSite(opts: {
  url: string;
  screenshot: boolean;
  extractText: boolean;
  maxLinks: number;
}): Promise<SiteInspection> {
  const browser = await chromium.launch({ headless: true });
  const page = await browser.newPage({ viewport: { width: 1280, height: 720 } });

  try {
    await page.goto(opts.url, { waitUntil: "domcontentloaded", timeout: 60_000 });
    const finalUrl = page.url();
    const title = await page.title();
    const html = await page.content();
    const links = await page.$$eval("a[href]", (as, maxLinks) => {
      const out: any[] = [];
      for (const a of as.slice(0, maxLinks as number)) {
        out.push({ href: (a as HTMLAnchorElement).href, text: (a.textContent ?? "").trim() });
      }
      return out;
    }, opts.maxLinks);

    let text: string | undefined;
    if (opts.extractText) {
      text = await page.$eval("body", (b) => (b.textContent ?? "").replace(/\s+/g, " ").trim());
    }

    let screenshotBase64: string | undefined;
    if (opts.screenshot) {
      const buf = await page.screenshot({ fullPage: true });
      screenshotBase64 = buf.toString("base64");
    }

    return { url: opts.url, finalUrl, title, html, text, links, screenshotBase64 };
  } finally {
    await page.close().catch(() => {});
    await browser.close().catch(() => {});
  }
}
