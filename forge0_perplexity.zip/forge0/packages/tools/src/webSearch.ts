import { request } from "undici";

export interface WebSearchResult {
  title: string;
  url: string;
  snippet?: string;
}

export interface WebSearchProvider {
  search(query: string, maxResults: number): Promise<WebSearchResult[]>;
}

/**
 * Perplexity Search API provider.
 *
 * Docs: https://docs.perplexity.ai/api-reference/search-post
 */
export class PerplexitySearch implements WebSearchProvider {
  constructor(private opts: { apiKey: string; baseUrl?: string }) {}

  async search(query: string, maxResults: number): Promise<WebSearchResult[]> {
    const baseUrl = (this.opts.baseUrl ?? "https://api.perplexity.ai").replace(/\/+$/, "");
    const url = `${baseUrl}/search`;

    const res = await request(url, {
      method: "POST",
      headers: {
        authorization: `Bearer ${this.opts.apiKey}`,
        "content-type": "application/json",
        "user-agent": "forge0/1.0",
      },
      body: JSON.stringify({
        query,
        max_results: Math.max(1, Math.min(20, maxResults)),
      }),
    });

    const raw = await res.body.text();
    if (res.statusCode < 200 || res.statusCode >= 300) {
      throw new Error(`Perplexity Search API error ${res.statusCode}: ${raw.slice(0, 400)}`);
    }

    const data = safeJson(raw);
    const results = Array.isArray(data?.results) ? data.results : [];
    return results
      .map((r: any) => ({
        title: String(r?.title ?? ""),
        url: String(r?.url ?? ""),
        snippet: r?.snippet ? String(r.snippet) : undefined,
      }))
      .filter((r: WebSearchResult) => r.title && r.url)
      .slice(0, maxResults);
  }
}

/**
 * DDG HTML scraping provider. Works in dev; for prod you probably want a proper search API.
 */
export class DuckDuckGoSearch implements WebSearchProvider {
  async search(query: string, maxResults: number): Promise<WebSearchResult[]> {
    const q = encodeURIComponent(query);
    const url = `https://duckduckgo.com/html/?q=${q}`;
    const res = await request(url, { headers: { "user-agent": "forge0/1.0" } });
    const html = await res.body.text();
    // cheap parsing (no DOM): extract result anchors
    const out: WebSearchResult[] = [];
    const re = /<a[^>]+class="result__a"[^>]+href="([^"]+)"[^>]*>(.*?)<\/a>/g;
    let m: RegExpExecArray | null;
    while ((m = re.exec(html)) && out.length < maxResults) {
      const href = m[1];
      const title = stripTags(m[2]);
      out.push({ title, url: href });
    }
    return out;
  }
}

function safeJson(s: string) {
  try {
    return JSON.parse(s);
  } catch {
    return null;
  }
}

function stripTags(s: string) {
  return s.replace(/<[^>]*>/g, "").replace(/\s+/g, " ").trim();
}
