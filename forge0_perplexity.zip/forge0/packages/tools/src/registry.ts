import type { WorkspaceManager } from "@forge0/workspace";
import {
  zTool_sandbox_exec,
  zTool_sandbox_install,
  zTool_verify_run,
  zTool_web_inspect,
  zTool_web_search,
  zTool_workspace_applyPatch,
  zTool_workspace_commit,
  zTool_workspace_read,
  zTool_workspace_tree,
  zTool_workspace_write,
} from "@forge0/shared";
import { DuckDuckGoSearch, PerplexitySearch, type WebSearchProvider } from "./webSearch.js";
import { inspectSite } from "./webInspect.js";

export interface SandboxClient {
  exec(args: any): Promise<{ code: number; stdout: string; stderr: string }>;
  install(args: any): Promise<{ code: number; stdout: string; stderr: string }>;
}

export interface VerifyClient {
  run(args: any): Promise<{ ok: boolean; report: any }>;
}

export function createToolRegistry(deps: {
  workspace: WorkspaceManager;
  sandbox: SandboxClient;
  verify: VerifyClient;
  /** Optional override for web.search provider. */
  search?: WebSearchProvider;
}) {
  const search = deps.search ?? defaultSearchProvider();

  return {
    "workspace.tree": async (raw: unknown) => {
      const args = zTool_workspace_tree.parse(raw);
      return await deps.workspace.tree(args.projectId, args.maxDepth);
    },
    "workspace.read": async (raw: unknown) => {
      const args = zTool_workspace_read.parse(raw);
      return await deps.workspace.readFile(args.projectId, args.path);
    },
    "workspace.write": async (raw: unknown) => {
      const args = zTool_workspace_write.parse(raw);
      await deps.workspace.writeFile(args.projectId, args.path, args.content);
      return { ok: true };
    },
    "workspace.applyPatch": async (raw: unknown) => {
      const args = zTool_workspace_applyPatch.parse(raw);
      await deps.workspace.applyPatch(args.projectId, args.patch);
      return { ok: true };
    },
    "workspace.commit": async (raw: unknown) => {
      const args = zTool_workspace_commit.parse(raw);
      return await deps.workspace.commit(args.projectId, args.message, args.branch);
    },
    "sandbox.exec": async (raw: unknown) => {
      const args = zTool_sandbox_exec.parse(raw);
      return await deps.sandbox.exec(args);
    },
    "sandbox.install": async (raw: unknown) => {
      const args = zTool_sandbox_install.parse(raw);
      return await deps.sandbox.install(args);
    },
    "verify.run": async (raw: unknown) => {
      const args = zTool_verify_run.parse(raw);
      return await deps.verify.run(args);
    },
    "web.search": async (raw: unknown) => {
      const args = zTool_web_search.parse(raw);
      return await search.search(args.query, args.maxResults);
    },
    "web.inspect": async (raw: unknown) => {
      const args = zTool_web_inspect.parse(raw);
      return await inspectSite(args);
    },
  } as const;
}

function defaultSearchProvider(): WebSearchProvider {
  const apiKey = process.env.PERPLEXITY_API_KEY ?? process.env.PPLX_API_KEY;
  const baseUrl = process.env.PERPLEXITY_BASE_URL ?? process.env.PPLX_BASE_URL;
  if (apiKey) return new PerplexitySearch({ apiKey, baseUrl });
  return new DuckDuckGoSearch();
}

export type ToolRegistry = ReturnType<typeof createToolRegistry>;
