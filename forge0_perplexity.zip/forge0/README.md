# Forge0 — agentic web-app builder (v0-like)

This repo is a **full-stack, multi-agent, tool-using** web-app builder inspired by the product category of "prompt → app".
It is designed as a **control plane + agent workers + sandbox runner + web UI**.

> You asked for a "full analog" (not a toy). So this is architected as a real system:
> - multi-agent orchestration (planner/ui/backend/qa/integrator + judge)
> - git-based workspaces (commits per iteration, branches/worktrees for parallel agents)
> - sandboxed build/run (Docker, resource limits, network modes)
> - automated verify + fix-loop (lint/typecheck/build + optional Playwright smoke)
> - web search + site inspection (Playwright + pluggable search provider)
> - preview gateway (reverse proxy + per-session routing)
> - export (zip or push to git remote)
> - audit trails + events + usage accounting

## Requirements
- Node.js 20+
- pnpm 9+
- Docker (for sandbox runner)
- PostgreSQL + Redis (docker-compose provided)

## Quick start
1) Copy envs:
```bash
cp .env.example .env
cp apps/control/.env.example apps/control/.env
cp apps/web/.env.example apps/web/.env
cp apps/worker/.env.example apps/worker/.env
cp packages/runner/.env.example packages/runner/.env
```

2) Start infra:
```bash
docker compose up -d postgres redis
```

3) Install deps:
```bash
pnpm i
```

4) DB migrate:
```bash
pnpm db:migrate
pnpm db:seed
```

5) Run dev:
```bash
pnpm dev
```

- Web UI: http://localhost:3000
- Control API: http://localhost:4000
- Runner API: http://localhost:5000

### LLM provider

By default the worker uses **Perplexity Sonar** via the OpenAI-compatible Chat Completions API.
Set `PERPLEXITY_API_KEY` (and optionally `PERPLEXITY_MODEL`, `PERPLEXITY_BASE_URL`) in `apps/worker/.env`.

## Project layout
- `apps/web` — Next.js UI (Chat + Files + Diff + Logs + Preview)
- `apps/control` — Fastify control plane API + auth + websocket events
- `apps/worker` — BullMQ workers (agent runs, verify runs, preview start/stop)
- `packages/db` — Prisma schema/client
- `packages/agent-core` — orchestrator + roles + judge + tool calling
- `packages/workspace` — git workspace manager (templates, worktrees, patches)
- `packages/tools` — tool registry (file ops, git ops, exec, search, inspect)
- `packages/runner` — Docker sandbox runner + preview gateway
- `packages/shared` — shared types + zod schemas

## Security notes
This project executes untrusted code in a **Docker sandbox**. You are responsible for hardening:
- Run runner on a locked-down host.
- Enable userns-remap / rootless Docker if possible.
- Configure network modes; default dev config allows outbound for installs.

See `packages/runner/SECURITY.md`.
